package com.java1234.servlet;

import javax.servlet.http.HttpServlet;

/**
 * ����ԱServlet��
 * @author Administrator
 *
 */
public class ManagerServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
